# ForYield – Simulateur (Streamlit)

## Local
pip install -r requirements.txt
streamlit run app.py

Les autres pages (ETH, USD, EUR) sont dans le menu des **Pages**.

## Déploiement
- Streamlit Community Cloud : connectez votre repo, entrypoint = app.py
